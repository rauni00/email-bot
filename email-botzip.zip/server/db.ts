import mongoose from "mongoose";

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  console.warn("MONGODB_URI is not set. Please set it in Secrets.");
}

export const connectDB = async () => {
  try {
    if (!MONGODB_URI) {
      console.log("Skipping MongoDB connection: No URI");
      return;
    }
    await mongoose.connect(MONGODB_URI);
    console.log("MongoDB connected");
  } catch (err) {
    console.error("MongoDB connection error:", err);
  }
};
