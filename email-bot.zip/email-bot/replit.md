# Email Engine

## Overview
A full-stack email automation application built with Express.js (backend) and React (frontend via Vite). It manages email contacts, sends bulk emails with configurable SMTP settings, and includes user authentication.

## Architecture
- **Frontend**: React 18 + Vite, TailwindCSS, shadcn/ui components, wouter routing
- **Backend**: Express 5 (TypeScript), served via `tsx`
- **Database**: MongoDB (Mongoose ODM)
- **Auth**: Passport.js with local strategy (email/password)
- **Session Store**: connect-mongo (MongoDB-backed sessions)

## Project Structure
```
client/           - React frontend (Vite)
  src/
    components/   - UI components (shadcn/ui based)
    pages/        - Page components
    hooks/        - React hooks
    lib/          - Utility functions
server/           - Express backend
  index.ts        - Entry point, Express app setup
  routes.ts       - API routes (contacts, settings, email engine)
  db.ts           - MongoDB connection
  storage.ts      - Data access layer (DatabaseStorage class)
  vite.ts         - Vite dev server middleware
  static.ts       - Production static file serving
  models/         - Mongoose schemas (User, Contact, Settings)
  replit_integrations/auth/ - Authentication (passport-local)
shared/           - Shared types and schemas (Zod)
  schema.ts       - Contact/Settings Zod schemas & types
  routes.ts       - API route definitions
  models/auth.ts  - User type definitions
uploads/          - File uploads directory
```

## Key Configuration
- **Port**: 5000 (single server serves both API and frontend)
- **Database**: MongoDB via `MONGODB_URI` secret
- **Session**: `SESSION_SECRET` secret
- **Dev Mode**: Vite middleware mode with HMR
- **Production**: Static files served from `dist/public`

## Scripts
- `npm run dev` - Development with dotenv
- `npm run build` - Build frontend (Vite) + bundle server (esbuild)
- `npm start` - Run production build

## Environment Variables
- `MONGODB_URI` (secret) - MongoDB connection string
- `SESSION_SECRET` (secret) - Express session secret
- `NODE_ENV` - Environment mode (development/production)
- `PORT` - Server port (default: 5000)
